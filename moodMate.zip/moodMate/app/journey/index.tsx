import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  TouchableOpacity, 
  TextInput, 
  ScrollView, 
  Modal, 
  KeyboardAvoidingView, 
  Platform 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useRoute, RouteProp } from '@react-navigation/native';

type RootStackParamList = {
  Journey: { noteTitle?: string };
};

type JourneyScreenRouteProp = RouteProp<RootStackParamList, 'Journey'>;

type Note = {
  id: string;
  title: string;
  content: string;
  date: string;
  time: string;
  type: 'JOURNAL' | 'MOOD_CHECK-IN';
  formatting?: {
    bold?: boolean;
    italic?: boolean;
    underline?: boolean;
    bulletPoints?: boolean;
  };
};

export default function Journey() {
  const route = useRoute<JourneyScreenRouteProp>();
  const [notes, setNotes] = useState<Note[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [activeTab, setActiveTab] = useState('Day');
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [viewNoteModalVisible, setViewNoteModalVisible] = useState(false);
  const [editMode, setEditMode] = useState(false);
  const [editedTitle, setEditedTitle] = useState('');
  const [editedContent, setEditedContent] = useState('');
  const [formatting, setFormatting] = useState({
    bold: false,
    italic: false,
    underline: false,
    bulletPoints: false
  });
  
  // Handle navigation params to open note editor with title
  useEffect(() => {
    if (route.params?.noteTitle) {
      setNoteTitle(route.params.noteTitle);
      setModalVisible(true);
    }
  }, [route.params?.noteTitle]);
  
  // Load notes from storage on component mount
  useEffect(() => {
    loadNotes();
  }, []);

  // Save notes to AsyncStorage
  const saveNotes = async (updatedNotes: Note[]) => {
    try {
      await AsyncStorage.setItem('notes', JSON.stringify(updatedNotes));
    } catch (error) {
      console.error('Error saving notes:', error);
    }
  };

  // Load notes from AsyncStorage
  const loadNotes = async () => {
    try {
      const savedNotes = await AsyncStorage.getItem('notes');
      if (savedNotes) {
        setNotes(JSON.parse(savedNotes));
      }
    } catch (error) {
      console.error('Error loading notes:', error);
    }
  };

  // Add a new note
  const addNote = () => {
    if (noteTitle.trim() === '' && noteContent.trim() === '') {
      return;
    }

    const now = new Date();
    const formattedDate = now.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
    });
    const formattedTime = now.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });

    const newNote: Note = {
      id: Date.now().toString(),
      title: noteTitle.trim() === '' ? 'Untitled Note' : noteTitle,
      content: noteContent,
      date: formattedDate,
      time: formattedTime,
      type: 'JOURNAL',
      formatting: {
        bold: formatting.bold,
        italic: formatting.italic,
        underline: formatting.underline,
        bulletPoints: formatting.bulletPoints
      }
    };

    const updatedNotes = [newNote, ...notes];
    setNotes(updatedNotes);
    saveNotes(updatedNotes);
    
    // Reset form and close modal
    setNoteTitle('');
    setNoteContent('');
    setFormatting({
      bold: false,
      italic: false,
      underline: false,
      bulletPoints: false
    });
    setModalVisible(false);
  };

  // View full note content
  const viewNote = (note: Note) => {
    setSelectedNote(note);
    setEditedTitle(note.title);
    setEditedContent(note.content);
    setViewNoteModalVisible(true);
    setEditMode(false);
  };

  // Update note after editing
  const updateNote = () => {
    if (!selectedNote) return;

    const updatedNote = {
      ...selectedNote,
      title: editedTitle.trim() === '' ? 'Untitled Note' : editedTitle,
      content: editedContent,
      formatting: {
        ...selectedNote.formatting,
        ...formatting
      }
    };

    const updatedNotes = notes.map(note => 
      note.id === selectedNote.id ? updatedNote : note
    );

    setNotes(updatedNotes);
    saveNotes(updatedNotes);
    setSelectedNote(updatedNote);
    setEditMode(false);
  };

  // Delete note
  const deleteNote = () => {
    if (!selectedNote) return;

    const updatedNotes = notes.filter(note => note.id !== selectedNote.id);
    setNotes(updatedNotes);
    saveNotes(updatedNotes);
    setViewNoteModalVisible(false);
    setSelectedNote(null);
  };

  // Toggle text formatting
  const toggleFormatting = (type: 'bold' | 'italic' | 'underline' | 'bulletPoints') => {
    setFormatting(prev => ({
      ...prev,
      [type]: !prev[type]
    }));
  };

  // Group notes by date
  const groupNotesByDate = () => {
    const grouped: Record<string, Note[]> = {};
    
    notes.forEach(note => {
      const dateKey = note.date;
      if (!grouped[dateKey]) {
        grouped[dateKey] = [];
      }
      grouped[dateKey].push(note);
    });
    
    return grouped;
  };

  // Format date for display
  const getFormattedDateLabel = (dateStr: string) => {
    const today = new Date();
    const formattedToday = today.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
    });
    
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const formattedYesterday = yesterday.toLocaleDateString('en-US', {
      day: 'numeric',
      month: 'short',
    });
    
    if (dateStr === formattedToday) {
      return 'Today';
    } else if (dateStr === formattedYesterday) {
      return 'Yesterday';
    } else {
      // Extract day name from date
      const date = new Date(dateStr);
      return date.toLocaleDateString('en-US', { weekday: 'long' });
    }
  };

  // Apply formatting to text for display
  const FormattedText = ({ text, noteFormatting }: { text: string, noteFormatting?: Note['formatting'] }) => {
    if (!noteFormatting) return <Text style={styles.noteContentText}>{text}</Text>;
    
    let textStyle: any = { ...styles.noteContentText };
    if (noteFormatting.bold) textStyle = { ...textStyle, fontWeight: 'bold' };
    if (noteFormatting.italic) textStyle = { ...textStyle, fontStyle: 'italic' };
    if (noteFormatting.underline) textStyle = { ...textStyle, textDecorationLine: 'underline' };
    
    if (noteFormatting.bulletPoints) {
      return (
        <View>
          {text.split('\n').map((line, index) => (
            <View key={index} style={styles.bulletPoint}>
              <Text style={{ color: '#CCCCCC', marginRight: 8 }}>•</Text>
              <Text style={textStyle}>{line}</Text>
            </View>
          ))}
        </View>
      );
    }
    
    return <Text style={textStyle}>{text}</Text>;
  };

  const groupedNotes = groupNotesByDate();
  const dateKeys = Object.keys(groupedNotes);

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.menuButton}>
          <Ionicons name="menu" size={24} color="#2D3142" />
        </TouchableOpacity>
        <Text style={styles.title}>Journey</Text>
        <TouchableOpacity 
          style={styles.addButton}
          onPress={() => setModalVisible(true)}
        >
          <Ionicons name="add-outline" size={28} color="#2D3142" />
        </TouchableOpacity>
      </View>

      {/* Time period tabs */}
      <View style={styles.tabContainer}>
        {['Day', 'Week', 'Month', 'Year'].map((tab) => (
          <TouchableOpacity
            key={tab}
            style={[styles.tabButton, activeTab === tab && styles.activeTab]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.activeTabText]}>
              {tab}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Notes list */}
      <ScrollView style={styles.notesContainer}>
        {dateKeys.length > 0 ? (
          dateKeys.map((dateKey) => (
            <View key={dateKey} style={styles.dateSection}>
              <View style={styles.dateSectionHeader}>
                <Text style={styles.dateSectionTitle}>
                  {getFormattedDateLabel(dateKey)}, {dateKey}
                </Text>
                <TouchableOpacity>
                  <Ionicons name="chevron-forward" size={24} color="#000" />
                </TouchableOpacity>
              </View>
              
              {groupedNotes[dateKey].map((note) => (
                <TouchableOpacity 
                  key={note.id} 
                  style={styles.noteCard}
                  onPress={() => viewNote(note)}
                >
                  <View style={styles.noteHeader}>
                    <View style={styles.noteIconContainer}>
                      {note.type === 'JOURNAL' ? (
                        <Ionicons name="document-text-outline" size={24} color="#666" />
                      ) : (
                        <Ionicons name="happy-outline" size={24} color="#666" />
                      )}
                    </View>
                    <View>
                      <Text style={styles.noteType}>
                        {note.type === 'JOURNAL' ? 'JOURNAL' : 'MOOD CHECK-IN'}
                      </Text>
                      <Text style={styles.noteTitle}>{note.title}</Text>
                    </View>
                    <Text style={styles.noteTime}>{note.time}</Text>
                  </View>
                  
                  {note.content && (
                    <View style={styles.noteContent}>
                      <FormattedText 
                        text={note.content} 
                        noteFormatting={note.formatting}
                      />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          ))
        ) : (
          <View style={styles.emptyState}>
            <Ionicons name="document-text-outline" size={60} color="#CCCCCC" />
            <Text style={styles.emptyStateText}>No notes yet</Text>
            <Text style={styles.emptyStateSubtext}>
              Start journaling by tapping the + button above
            </Text>
          </View>
        )}
      </ScrollView>

      {/* Add Note Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => setModalVisible(false)}
      >
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>New Journal Entry</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>
            
            <TextInput
              style={styles.titleInput}
              placeholder="Title (optional)"
              value={noteTitle}
              onChangeText={setNoteTitle}
              placeholderTextColor="#999"
            />
            
            {/* Formatting toolbar */}
            <View style={styles.formattingToolbar}>
              <TouchableOpacity 
                style={[
                  styles.formattingButton, 
                  formatting.bold && styles.activeFormattingButton
                ]}
                onPress={() => toggleFormatting('bold')}
              >
                <Text style={styles.formattingButtonText}>B</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.formattingButton, 
                  formatting.italic && styles.activeFormattingButton
                ]}
                onPress={() => toggleFormatting('italic')}
              >
                <Text style={[styles.formattingButtonText, { fontStyle: 'italic' }]}>I</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.formattingButton, 
                  formatting.underline && styles.activeFormattingButton
                ]}
                onPress={() => toggleFormatting('underline')}
              >
                <Text style={[styles.formattingButtonText, { textDecorationLine: 'underline' }]}>U</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={[
                  styles.formattingButton, 
                  formatting.bulletPoints && styles.activeFormattingButton
                ]}
                onPress={() => toggleFormatting('bulletPoints')}
              >
                <Ionicons name="list" size={18} color={formatting.bulletPoints ? "#FFF" : "#333"} />
              </TouchableOpacity>
            </View>
            
            <TextInput
              style={[
                styles.contentInput,
                formatting.bold && { fontWeight: 'bold' },
                formatting.italic && { fontStyle: 'italic' },
                formatting.underline && { textDecorationLine: 'underline' }
              ]}
              placeholder="Write your thoughts here..."
              value={noteContent}
              onChangeText={setNoteContent}
              multiline
              placeholderTextColor="#999"
              textAlignVertical="top"
            />
            
            <TouchableOpacity 
              style={styles.saveButton}
              onPress={addNote}
            >
              <Text style={styles.saveButtonText}>Save</Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>

      {/* View/Edit Note Modal */}
      <Modal
        animationType="slide"
        transparent={true}
        visible={viewNoteModalVisible}
        onRequestClose={() => setViewNoteModalVisible(false)}
      >
        <KeyboardAvoidingView 
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.modalContainer}
        >
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {editMode ? 'Edit Note' : 'View Note'}
              </Text>
              <TouchableOpacity onPress={() => setViewNoteModalVisible(false)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>

            {!editMode ? (
              <>
                <View style={styles.viewNoteHeader}>
                  <Text style={styles.viewNoteTitle}>{selectedNote?.title}</Text>
                  <Text style={styles.viewNoteDate}>
                    {selectedNote?.date} • {selectedNote?.time}
                  </Text>
                </View>

                <ScrollView style={styles.viewNoteContent}>
                  {selectedNote && (
                    <FormattedText 
                      text={selectedNote.content} 
                      noteFormatting={selectedNote.formatting}
                    />
                  )}
                </ScrollView>

                <View style={styles.viewNoteActions}>
                  <TouchableOpacity 
                    style={styles.viewNoteButton}
                    onPress={() => setEditMode(true)}
                  >
                    <Ionicons name="create-outline" size={22} color="#333" />
                    <Text style={styles.viewNoteButtonText}>Edit</Text>
                  </TouchableOpacity>

                  <TouchableOpacity 
                    style={[styles.viewNoteButton, styles.deleteButton]}
                    onPress={deleteNote}
                  >
                    <Ionicons name="trash-outline" size={22} color="#FF3B30" />
                    <Text style={[styles.viewNoteButtonText, { color: '#FF3B30' }]}>
                      Delete
                    </Text>
                  </TouchableOpacity>
                </View>
              </>
            ) : (
              <>
                <TextInput
                  style={styles.titleInput}
                  placeholder="Title (optional)"
                  value={editedTitle}
                  onChangeText={setEditedTitle}
                  placeholderTextColor="#999"
                />
                
                {/* Formatting toolbar for editing */}
                <View style={styles.formattingToolbar}>
                  <TouchableOpacity 
                    style={[
                      styles.formattingButton, 
                      formatting.bold && styles.activeFormattingButton
                    ]}
                    onPress={() => toggleFormatting('bold')}
                  >
                    <Text style={styles.formattingButtonText}>B</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[
                      styles.formattingButton, 
                      formatting.italic && styles.activeFormattingButton
                    ]}
                    onPress={() => toggleFormatting('italic')}
                  >
                    <Text style={[styles.formattingButtonText, { fontStyle: 'italic' }]}>I</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[
                      styles.formattingButton, 
                      formatting.underline && styles.activeFormattingButton
                    ]}
                    onPress={() => toggleFormatting('underline')}
                  >
                    <Text style={[styles.formattingButtonText, { textDecorationLine: 'underline' }]}>U</Text>
                  </TouchableOpacity>
                  
                  <TouchableOpacity 
                    style={[
                      styles.formattingButton, 
                      formatting.bulletPoints && styles.activeFormattingButton
                    ]}
                    onPress={() => toggleFormatting('bulletPoints')}
                  >
                    <Ionicons name="list" size={18} color={formatting.bulletPoints ? "#FFF" : "#333"} />
                  </TouchableOpacity>
                </View>
                
                <TextInput
                  style={[
                    styles.contentInput,
                    formatting.bold && { fontWeight: 'bold' },
                    formatting.italic && { fontStyle: 'italic' },
                    formatting.underline && { textDecorationLine: 'underline' }
                  ]}
                  placeholder="Write your thoughts here..."
                  value={editedContent}
                  onChangeText={setEditedContent}
                  multiline
                  placeholderTextColor="#999"
                  textAlignVertical="top"
                />
                
                <TouchableOpacity 
                  style={styles.saveButton}
                  onPress={updateNote}
                >
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFF',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
  },
  menuButton: {
    padding: 4,
  },
  title: {
    fontSize: 24,
    fontWeight: '600',
    color: '#2D3142',
  },
  addButton: {
    padding: 4,
  },
  tabContainer: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  tabButton: {
    flex: 1,
    paddingVertical: 16,
    alignItems: 'center',
  },
  activeTab: {
    borderBottomWidth: 2,
    borderBottomColor: '#000',
  },
  tabText: {
    fontSize: 18,
    color: '#999',
  },
  activeTabText: {
    color: '#000',
    fontWeight: '500',
  },
  notesContainer: {
    flex: 1,
  },
  dateSection: {
    marginBottom: 20,
  },
  dateSectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  dateSectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  noteCard: {
    backgroundColor: '#1c1c1e',
    borderRadius: 12,
    marginHorizontal: 16,
    marginBottom: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  noteHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  noteIconContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#333',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  noteType: {
    fontSize: 14,
    color: '#999',
    marginBottom: 2,
  },
  noteTitle: {
    fontSize: 16,
    fontWeight: '500',
    color: '#FFF',
    marginRight: 40,
  },
  noteTime: {
    position: 'absolute',
    right: 0,
    top: 0,
    fontSize: 14,
    color: '#999',
  },
  noteContent: {
    marginTop: 12,
    paddingLeft: 52,
  },
  noteContentText: {
    fontSize: 15,
    color: '#CCCCCC',
    lineHeight: 22,
  },
  bulletPoint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 100,
  },
  emptyStateText: {
    fontSize: 20,
    fontWeight: '500',
    color: '#666',
    marginTop: 16,
  },
  emptyStateSubtext: {
    fontSize: 16,
    color: '#999',
    marginTop: 8,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  modalContent: {
    backgroundColor: '#FFF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 16,
    paddingBottom: 30,
    height: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  titleInput: {
    fontSize: 18,
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  formattingToolbar: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  formattingButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    marginRight: 12,
  },
  activeFormattingButton: {
    backgroundColor: '#000',
  },
  formattingButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  contentInput: {
    flex: 1,
    fontSize: 16,
    padding: 16,
    lineHeight: 24,
  },
  saveButton: {
    backgroundColor: '#000',
    borderRadius: 8,
    padding: 16,
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 16,
  },
  saveButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  viewNoteHeader: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  viewNoteTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  viewNoteDate: {
    fontSize: 14,
    color: '#999',
  },
  viewNoteContent: {
    flex: 1,
    padding: 16,
  },
  viewNoteActions: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#EFEFEF',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  viewNoteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    marginRight: 16,
    borderRadius: 8,
    backgroundColor: '#F5F5F5',
  },
  viewNoteButtonText: {
    marginLeft: 8,
    fontSize: 16,
    color: '#333',
  },
  deleteButton: {
    backgroundColor: '#FFF0F0',
  },
}); 
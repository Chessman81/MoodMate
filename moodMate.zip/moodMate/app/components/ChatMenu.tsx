import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList } from 'react-native';
import { useNavigation } from '@react-navigation/native';

type ChatMenuProps = {
  conversations: any[];
  onChatPress: (conversationId: string) => void;
  onNewChat: () => void;
};

export default function ChatMenu({ conversations, onChatPress, onNewChat }: ChatMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const renderConversation = ({ item }: { item: any }) => (
    <TouchableOpacity 
      style={styles.conversationItem}
      onPress={() => {
        onChatPress(item.id);
        toggleMenu();
      }}
    >
      <View style={styles.conversationContent}>
        <Text style={styles.conversationTitle}>{item.title}</Text>
        <Text style={styles.conversationDate}>
          {new Date(item.updated_at).toLocaleDateString()}
        </Text>
      </View>
      <Text style={{ color: '#BBB', fontSize: 20 }}>›</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Menu Button Bar */}
      <View style={styles.menuBar}>
        <TouchableOpacity 
          style={styles.menuButton}
          onPress={toggleMenu}
          accessibilityLabel="Open chat menu"
        >
          <View style={styles.hamburgerIcon}>
            <View style={styles.hamburgerLine} />
            <View style={styles.hamburgerLine} />
            <View style={styles.hamburgerLine} />
          </View>
          <Text style={styles.menuButtonText}>MENU</Text>
        </TouchableOpacity>
      </View>

      {/* Chat History Panel */}
      {isOpen && (
        <View style={styles.menuPanel}>
          <View style={styles.menuHeader}>
            <Text style={styles.menuHeaderText}>Chat History</Text>
            <TouchableOpacity onPress={toggleMenu} style={styles.closeButton}>
              <Text style={styles.closeButtonText}>✕ CLOSE</Text>
            </TouchableOpacity>
          </View>

          <TouchableOpacity 
            style={styles.newChatItem}
            onPress={() => {
              onNewChat();
              toggleMenu();
            }}
          >
            <Text style={styles.newChatText}>+ Start New Chat</Text>
          </TouchableOpacity>

          <FlatList
            data={conversations}
            renderItem={renderConversation}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.conversationList}
            ListEmptyComponent={
              <View style={styles.emptyContainer}>
                <Text style={styles.emptyText}>No conversations yet</Text>
                <Text style={styles.emptySubtext}>Start a new chat to begin</Text>
              </View>
            }
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    zIndex: 100,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
  },
  menuBar: {
    paddingTop: 40,
    paddingHorizontal: 15,
    marginBottom: 10,
  },
  menuButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#6B64F3',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  hamburgerIcon: {
    marginRight: 8,
  },
  hamburgerLine: {
    width: 16,
    height: 2,
    backgroundColor: 'white',
    marginVertical: 2,
  },
  menuButtonText: {
    color: 'white',
    fontWeight: 'bold',
    fontSize: 14,
  },
  menuPanel: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'white',
    zIndex: 1000,
    flex: 1,
    height: '100%',
  },
  menuHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingTop: 50,
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
    backgroundColor: '#F8F8FC',
  },
  menuHeaderText: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#2D3142',
  },
  closeButton: {
    padding: 8,
  },
  closeButtonText: {
    color: '#6B64F3',
    fontWeight: 'bold',
    fontSize: 14,
  },
  newChatItem: {
    padding: 16,
    backgroundColor: '#F8F8FC',
    borderBottomWidth: 1,
    borderBottomColor: '#EFEFEF',
  },
  newChatText: {
    color: '#6B64F3',
    fontWeight: '600',
    fontSize: 16,
  },
  conversationList: {
    padding: 16,
  },
  conversationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  conversationContent: {
    flex: 1,
  },
  conversationTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2D3142',
    marginBottom: 4,
  },
  conversationDate: {
    fontSize: 14,
    color: '#999',
  },
  emptyContainer: {
    padding: 32,
    alignItems: 'center',
  },
  emptyText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#2D3142',
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 14,
    color: '#999',
  },
}); 
/**
 * Claude AI Service - A wrapper for Anthropic's Claude API
 * 
 * This service provides methods to interact with Claude, handling authentication,
 * request formatting, and error management.
 */

// Claude API documentation reference: https://docs.anthropic.com/claude/reference/

import env from '../utils/env';

// Types for Claude API requests and responses
export type ClaudeMessage = {
  role: 'user' | 'assistant' | 'system';
  content: string;
};

export type ClaudeResponse = {
  id: string;
  type: string;
  role: string;
  content: Array<{
    type: string;
    text: string;
  }>;
  model: string;
  stop_reason: string | null;
  stop_sequence: string | null;
  usage: {
    input_tokens: number;
    output_tokens: number;
  };
};

export type ClaudeError = {
  type: string;
  message: string;
  details?: string;
};

// System instructions for MoodMate
const MOODMATE_SYSTEM_INSTRUCTIONS = `You are MoodMate, an empathetic AI assistant developed by MoodMate Inc. Your primary role is to help users cope with stress, anxiety, and improve emotional well-being.

Tone and Style:
- Always use an empathetic, calming, and reassuring tone
- Be supportive, positive, and solution-focused
- Provide practical coping strategies and actionable suggestions rather than generic advice

Content and Depth:
- Prioritize concise yet thorough responses, typically 2–4 sentences
- When suggesting coping strategies, prioritize evidence-based techniques such as mindfulness, cognitive reframing, grounding exercises, and breathing exercises
- Avoid clinical jargon; keep explanations simple and understandable for general users

Engagement Guidelines:
- Encourage positive interaction by occasionally checking in, asking supportive follow-up questions, or gently suggesting self-reflection
- If the user expresses significant distress or mentions harm, gently suggest seeking professional support

Limitations and Boundaries:
- Never attempt to diagnose or offer medical treatment
- Clearly and kindly redirect users to professional mental health resources if needed

Formatting and Presentation:
- Use friendly emojis (🌿, 😊, 🧘‍♀️, etc.) sparingly to reinforce positive emotional tone
- Use formatting (bullet points, numbered lists) when recommending multiple strategies or actionable steps`;

// Claude API wrapper class
class ClaudeService {
  private apiKey: string | null = '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';
  private apiUrl = 'https://api.anthropic.com/v1/messages';
  private defaultModel = 'claude-3-5-haiku-20241022';
  
  /**
   * Set the API key for Claude API
   * @param key - The API key from Anthropic
   */
  setApiKey(key: string) {
    this.apiKey = key;
  }
  
  /**
   * Check if the API key is set
   * @returns True if the API key is set, false otherwise
   */
  hasApiKey(): boolean {
    return this.apiKey !== null && this.apiKey.trim() !== '';
  }

  /**
   * Send a message to Claude and get a response
   * @param message - The user message to send
   * @param conversation - Optional previous messages for context
   * @returns A promise that resolves to Claude's response text
   * @throws Error if API key is not set or if the request fails
   */
  async sendMessage(
    message: string, 
    conversation: ClaudeMessage[] = []
  ): Promise<string> {
    // Validate API key
    if (!this.hasApiKey()) {
      console.error('Claude API Key missing or empty');
      throw new Error('No API key found. Please set your Claude API key.');
    }

    try {
      console.log('Sending request to Claude API...');
      
      // Filter out any system messages from conversation (they're not allowed in messages array)
      const filteredConversation = conversation.filter(msg => msg.role !== 'system');
      
      // Prepare request body according to Claude API spec
      // The system instruction should be a top-level parameter, not in the messages array
      const requestBody = {
        model: this.defaultModel,
        system: MOODMATE_SYSTEM_INSTRUCTIONS, // Move system prompt to top level
        messages: [
          ...filteredConversation,
          { role: 'user', content: message }
        ],
        max_tokens: 1024,
        temperature: 0.7,
      };

      console.log(`Using Claude model: ${this.defaultModel}`);
      
      try {
        // Set timeout for the fetch request
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10-second timeout

        // Make API request to Claude
        console.log('Making API request to:', this.apiUrl);
        const response = await fetch(this.apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': this.apiKey as string,
            'anthropic-version': '2023-06-01'
          },
          body: JSON.stringify(requestBody),
          signal: controller.signal
        });

        // Clear the timeout
        clearTimeout(timeoutId);

        // Log response status
        console.log('Claude API response status:', response.status);
        
        // Handle error responses
        if (!response.ok) {
          const errorText = await response.text();
          console.error('Raw error response:', errorText);
          // Throw a simple error to be caught below
          throw new Error(`HTTP error ${response.status}`); 
        }

        // Parse the successful response
        const data = await response.json() as ClaudeResponse;
        console.log('Claude API response received successfully with model:', data.model);
        
        // Extract and return text from the response
        const responseText = data.content[0]?.text || '';
        if (!responseText) {
          console.warn('Claude API returned empty response text');
          return "(Claude returned an empty response)";
        }
        return responseText;
      } catch (error) {
        // Re-throw the error so it's handled by the calling component
        console.error('Error during Claude API fetch:', error);
        if (error instanceof Error) {
           // Provide more specific messages for common network issues
           if (error.name === 'AbortError') {
             throw new Error('Request timed out');
           } else if (error.message.includes('Network request failed') || error.message.includes('Failed to fetch')) {
             throw new Error('Network request failed');
           }
        }
        // Re-throw original or a generic error
        throw error; 
      }
    } catch (error) {
      // This catch block is for setup errors before the fetch
      console.error('Unexpected error in Claude service setup:', error);
      // Let the calling component handle this with its own error message/fallback
      throw error;
    }
  }
}

// Create and export a singleton instance
const claudeService = new ClaudeService();
export default claudeService;
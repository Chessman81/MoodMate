import React, { useState, useEffect, createContext, useContext, ReactNode } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions } from 'react-native';

// Types
type ToastType = 'success' | 'error' | 'info';

type ToastMessage = {
  id: string;
  message: string;
  type: ToastType;
  duration?: number;
};

type ToastContextType = {
  showToast: (message: string, type?: ToastType, duration?: number) => void;
};

// Default context value
const ToastContext = createContext<ToastContextType>({
  showToast: () => {},
});

// Custom hook to use the toast
export const useToast = () => useContext(ToastContext);

// Toast Provider Component
export const ToastProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  
  const showToast = (
    message: string, 
    type: ToastType = 'info', 
    duration: number = 3000
  ) => {
    const id = Date.now().toString();
    setToasts(prevToasts => [...prevToasts, { id, message, type, duration }]);
    
    // Auto remove the toast after duration
    setTimeout(() => {
      setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    }, duration);
  };
  
  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <View style={styles.toastContainer}>
        {toasts.map(toast => (
          <ToastItem key={toast.id} toast={toast} />
        ))}
      </View>
    </ToastContext.Provider>
  );
};

// Individual Toast Item
const ToastItem: React.FC<{ toast: ToastMessage }> = ({ toast }) => {
  const { type, message } = toast;
  const opacity = new Animated.Value(0);
  
  useEffect(() => {
    // Animation sequence
    Animated.sequence([
      Animated.timing(opacity, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }),
      Animated.delay(toast.duration ? toast.duration - 600 : 2400),
      Animated.timing(opacity, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);
  
  // Get background color based on type
  const getBgColor = () => {
    switch (type) {
      case 'success':
        return '#4CAF50';
      case 'error':
        return '#F44336';
      default:
        return '#2196F3';
    }
  };
  
  return (
    <Animated.View 
      style={[
        styles.toast, 
        { backgroundColor: getBgColor(), opacity }
      ]}
    >
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
};

// Styles
const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  toastContainer: {
    position: 'absolute',
    top: 60,
    width: '100%',
    zIndex: 9999,
    alignItems: 'center',
  },
  toast: {
    marginVertical: 5,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
    minWidth: width * 0.7,
    maxWidth: width * 0.9,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },
  toastText: {
    color: '#FFFFFF',
    fontSize: 16,
    textAlign: 'center',
  },
});
import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { supabase } from '../services/supabase';

export default function SupabaseTest() {
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const testConnection = async () => {
      try {
        // Try to fetch a single row from the conversations table
        const { data, error } = await supabase
          .from('conversations')
          .select('*')
          .limit(1);
        
        if (error) throw error;
        
        setStatus('success');
      } catch (err) {
        console.error('Supabase connection error:', err);
        setError(err instanceof Error ? err.message : 'Unknown error');
        setStatus('error');
      }
    };

    testConnection();
  }, []);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Supabase Connection Test</Text>
      
      {status === 'loading' && (
        <View style={styles.statusContainer}>
          <ActivityIndicator size="large" color="#6B64F3" />
          <Text style={styles.statusText}>Testing connection...</Text>
        </View>
      )}
      
      {status === 'success' && (
        <View style={styles.statusContainer}>
          <Text style={[styles.statusText, styles.successText]}>
            ✅ Connection successful!
          </Text>
          <Text style={styles.subText}>
            Your Supabase connection is working correctly.
          </Text>
        </View>
      )}
      
      {status === 'error' && (
        <View style={styles.statusContainer}>
          <Text style={[styles.statusText, styles.errorText]}>
            ❌ Connection failed
          </Text>
          <Text style={styles.errorDetails}>{error}</Text>
          <Text style={styles.subText}>
            Please check your Supabase configuration and try again.
          </Text>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#F8F8FC',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 30,
    color: '#2D3142',
  },
  statusContainer: {
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    width: '100%',
  },
  statusText: {
    fontSize: 18,
    fontWeight: '600',
    marginTop: 10,
    marginBottom: 5,
  },
  successText: {
    color: '#4CAF50',
  },
  errorText: {
    color: '#F44336',
  },
  errorDetails: {
    color: '#F44336',
    marginBottom: 10,
    textAlign: 'center',
  },
  subText: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
}); 
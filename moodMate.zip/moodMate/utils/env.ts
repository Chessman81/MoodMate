import Constants from 'expo-constants';

// Define the shape of your environment variables
interface Env {
  EXPO_PUBLIC_SUPABASE_URL: string;
  EXPO_PUBLIC_SUPABASE_ANON_KEY: string;
  EXPO_PUBLIC_CLAUDE_API_KEY: string;
}

// Get the environment variables
const getEnvVars = (): Env => {
  // For development
  if (__DEV__) {
    return {
      EXPO_PUBLIC_SUPABASE_URL: process.env.EXPO_PUBLIC_SUPABASE_URL || '',
      EXPO_PUBLIC_SUPABASE_ANON_KEY: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '',
      EXPO_PUBLIC_CLAUDE_API_KEY: process.env.EXPO_PUBLIC_CLAUDE_API_KEY || '',
    };
  }
  
  // For production
  return {
    EXPO_PUBLIC_SUPABASE_URL: Constants.expoConfig?.extra?.EXPO_PUBLIC_SUPABASE_URL || '',
    EXPO_PUBLIC_SUPABASE_ANON_KEY: Constants.expoConfig?.extra?.EXPO_PUBLIC_SUPABASE_ANON_KEY || '',
    EXPO_PUBLIC_CLAUDE_API_KEY: Constants.expoConfig?.extra?.EXPO_PUBLIC_CLAUDE_API_KEY || '',
  };
};

export default getEnvVars(); 